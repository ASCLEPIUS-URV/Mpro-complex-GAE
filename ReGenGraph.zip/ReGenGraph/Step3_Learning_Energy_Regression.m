function Regress_W=Step3_Learning_Energy_Regression(AhL,XL,EL,W01,n)
%% Learning Regression
for i=1:size(XL,3)
    Zstr=GCN(AhL(:,:,i),XL(:,1:3,i),W01); %check we only select one feature
    [Znode,~] = myNeuralNetworkFunction(XL(:,4,i));
    Znode=dlarray(Znode);
    ZFinal(i,:)=Z_Compress(Zstr,Znode',n(i));  
end
ZFinal=extractdata(ZFinal);
ZFinal(:,end+1)=ones(size(ZFinal,1),1); 
% figure
% histogram(reshape(ZFinal,1,[]));
% title('Latent Domain')
%% Regression
%saving latent vectors for NN
save('EL_y','EL')
save('zfinal_x','ZFinal');
Regress_W = dlarray(regress(EL,ZFinal)); 
end