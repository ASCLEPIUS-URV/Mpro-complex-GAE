clc; clear all; close all;
%% Reading data
load('W01');
load('net');
load('Regress_W')

Read_Data

  Ep = Compute_Energy_All_NN(AhT,XT,W01,net,num_features);
  plot_energy_accuracy(ET,Ep,'Neural Network')
  Ep = Compute_Energy_All_Regression(AhT,XT,W01,num_features,Regress_W);
  plot_energy_accuracy(ET,Ep,'Regression')
 load('Ep_1NN');
 ET=ET(1:length(Ep));
 plot_energy_accuracy(ET,Ep,'1-NN')
%% End of script


%% Functions


function Ep = Compute_Energy_All_NN(AhT,XT,W01,network,num_features)
Ep=dlarray(zeros(size(XT,3),1));
for i=1:size(XT,3)
    Z=GCN(AhT(:,:,i),XT(:,:,i),W01,num_features);
    Z_linear=extractdata([reshape(Z,1,[]),1]);
    Ep(i)=network(Z_linear'); %modify with new NN
end
Ep = extractdata(Ep);
end

