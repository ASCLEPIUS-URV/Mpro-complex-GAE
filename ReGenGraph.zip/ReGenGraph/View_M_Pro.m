clc, clear, close all

[filename, pathname]=uigetfile('./01-protein-coordinates/02-Mol2-format/*.mol2','Protein');
molviewer(strcat(pathname,filename));

[filename, pathname]=uigetfile('./02-ligands-coordinates/02-Mol2-format/*.mol2','Ligand');
molviewer(strcat(pathname,filename));
