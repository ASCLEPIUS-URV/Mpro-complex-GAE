function [Reconstruction_error,Degre_Ap,Degre_A,Z]=Step1_Validating_Reconstruction_Edges(A,Ah,X,nn,W01)
for kkk=1:size(X,3)
 n=1:nn(kkk);
 Z=GCN(Ah(n,n,kkk),X(n,:,kkk),W01);
  Ap=Decoder(Z);
  for i=1:size(Ap,1)
   for j=1:size(Ap,2)  
    if Ap(i,j)>0.5
      Ap(i,j)=1;
    else
      Ap(i,j)=0;
    end
   end
  end
  Reconstruction_error(kkk)=sum(sum(abs(Ap(n,n)-A(n,n,kkk))))/(nn(kkk)*nn(kkk));
  Degre_Ap(kkk)=sum(sum(Ap(n,n)))/(nn(kkk)*nn(kkk));
  Degre_A(kkk)=sum(sum(A(n,n)))/(nn(kkk)*nn(kkk));
end
Reconstruction_error=extractdata(Reconstruction_error);
Degre_Ap=extractdata(Degre_Ap);
Degre_A=extractdata(Degre_A);
end