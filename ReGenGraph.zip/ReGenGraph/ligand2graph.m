function [error,Graph]=ligand2graph(filename)
   fileID = fopen(filename,'r');
   if fileID >=0
   nothingtodo=fscanf(fileID,'%s',2);
   Graph.numnodes=fscanf(fileID,'%d',1);
   Graph.numedges=fscanf(fileID,'%d',1);
   nothingtodo=fscanf(fileID,'%d',1);
   nothingtodo=fscanf(fileID,'%s',4);
   Graph.Nodes = zeros(Graph.numnodes,4,'double');
   for i=1:Graph.numnodes
       nothingtodo=fscanf(fileID,'%d',1);
       atom=fscanf(fileID,'%s', 1);
       atomic_number=Atomic_number(atom(1));
       Graph.Nodes(i,4)=atomic_number;
       Graph.Nodes(i,1:3)=fscanf(fileID,'%f',3);
       ignoredLine=fgetl(fileID); 
   end
   mat=zeros(Graph.numnodes,Graph.numnodes,'int8');
   for i=1:Graph.numnodes
       nothingtodo=fscanf(fileID,'%d',1);
       colTwo=fscanf(fileID,'%d',1);
       colThree=fscanf(fileID,'%d',1);
       colFour=fscanf(fileID,'%s',1);
       if(colFour=="ar")
           colFour=101;
       elseif(colFour=="am")
           colFour=102;
       else
           colFour=str2num(colFour);
       end
       mat(colTwo,colThree)=colFour;
       mat(colThree,colTwo)=colFour;
   end
   Graph.Edges=mat;
   fclose(fileID);
   end
   error=fileID<0;
end