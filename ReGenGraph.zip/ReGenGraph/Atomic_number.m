function atomic_number = Atomic_number(atom)
    switch atom
    case 'C' 
        atomic_number = 6;
    case 'H'
       atomic_number = 1;
    case 'O'
       atomic_number = 8;
    case 'N'
       atomic_number = 7;
    case 'S'
       atomic_number = 16;
    case 'F'
        atomic_number = 9;
    case 'I'
        atomic_number = 53;
    case 'B'
        atomic_number = 5;  
    case 'P'
        atomic_number = 15;  
    otherwise
        disp(atom);
    end
end