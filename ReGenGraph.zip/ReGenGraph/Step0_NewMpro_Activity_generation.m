clc, clear, close all
[FILENAME, PATHNAME] = uigetfile('./*.xlsx');
[NUM,TXT,Activity]=xlsread(strcat(PATHNAME,FILENAME));
save('NewMPro_DB_Activity','Activity');