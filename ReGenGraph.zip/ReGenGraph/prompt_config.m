%Prompting the user for encoder configurations.


%Prompting the user for model configurations.

prompt_train = "Enter number of training tokens. Default 5000" + newline;
Num_Graph_Learn = input(prompt_train);

prompt_test = "Enter number of testing tokens. Default 2165" + newline;
Num_Graph_Test = input(prompt_test);

%AE
prompt_AE = "Enter size of AE hidden layer. Default 10" + newline;
Dhiden_NAE= input(prompt_AE);

%GAE
prompt_GAE_hid = "Enter size of GAE hidden layer. Default 20" + newline ;
Dhid = input(prompt_GAE_hid); %initial value=20 % Dimension of the hiden layer.

prompt_GAE_out = "Enter size of GAE output layer.Default 100" + newline;
Dout = input(prompt_GAE_out);  % Dimension of the latent domain. default 100

prompt_num_ep = "Enter number of training epcohs. Default 20" + newline;
numEpochs = input(prompt_num_ep); % Epoch of the GAE default 20
