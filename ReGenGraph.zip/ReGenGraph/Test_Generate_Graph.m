
[N1,E1]=Random_Graph(3, 3, 5);
[N2,E2]=Random_Graph(4, 3, 5);
N2=N2+10;
[N3,E3]=Generate_Graph(N1,N2,E1,E2,100,4);