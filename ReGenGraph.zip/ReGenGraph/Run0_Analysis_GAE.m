clc, clear all, close all
 global A;
 global Ah;
 global X;
 global Dhid;
 global Dout;
 global nn; % number of real nodes before enlargement
%% Parameters
Dhid=20; % Dimension of the hiden layer
Dout=30; % Dimension of the output layer
numEpochs = 200; % Epoch of the GAE
learnRate = 0.01; % 
Nodes=20;
Features=4;
Graphs = 1;
Threshold=0.5;
%% End Parameters

%% Initialising graphs
for g=1:Graphs
X(:,:,g)= rand(Nodes,Features)-0.5;
A(:,:,g) = zeros(Nodes);
for i=1:size(X,1)
 for j=1:size(X,1)
     if norm(X(i,1:3,g)-X(j,1:3,g)) < Threshold
        A(i,j,g) = 1;
     end
 end
end
Ah(:,:,g)=A2Ah(A(:,:,g));
nn(g)=Nodes;
end
Ah=dlarray(Ah);
A=dlarray(A);
X=dlarray(X);
%% End Initialising graphs

for i=4:size(X,2)-1
    Xin(:,i)=reshape(X(:,i,:),1,[]);
    Xout(:,i)=reshape(X(:,i,:),1,[]);
end
% Learning AE
 nnstart
% [a1,y1]. Add a1 in myNeuralNetworkFunction_Analysis
 pause

NN=@myNeuralNetworkFunction_Analysis;
W01=Step1_Learning_GAE(Dhid,Dout,numEpochs,learnRate);
[error_str,Degre_Ap,Degre_A,Z]=Step1_Validating_Reconstruction_Edges(A,Ah,X,nn,W01);
[error_nodes,XXout]=Step1_Validating_Reconstruction_Nodes(extractdata(X'),NN);
%
[error_str,Degre_Ap,Degre_A,error_nodes]
histogram(extractdata(reshape(Z,[],1)))