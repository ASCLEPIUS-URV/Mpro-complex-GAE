clc, clear all, close all

load('Ligand.mat')
nn = Ligand.numnodes;

%Loading saved data
DataLearn = 'Ligand.mat';
DataTest = 'Ligand.mat';
ActivityLearn='Activity.mat';
ActivityTest = 'Activity.mat';


%Filtering graphs by size
Filter = find(nn>=0 & nn<=150);
% Learn = [Filter(1:47), Filter(57:107)];
% Test = Filter(48:56);

Learn = Filter(1:160);
Test = Learn;
nn_Learn=nn;
nn_Test=nn;

%Autoencoder
Dhiden_AE=20;

%GAE
Dhid=100; % Dimension of the hiden layer.
Dout=20;  % Dimension of the latent domain.
numEpochs = 35; % Epochs of the GAE
