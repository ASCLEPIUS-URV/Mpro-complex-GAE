clc; clear all; close all;
 global W01;
 global Ah1;
 global num_features;
 global Regress_W
%% Parameters
alpha=0.01;

%% Reading data
load('W01');
load('Num_Graph_Learn');
load('QM7_DB.mat')
load('Regress_W')
  for i=Num_Graph_Learn+1:length(QM7_DB.Energy)
    a=QM7_DB.atomicNumber(i,:)';
    p=reshape(QM7_DB.pos3D(i,:,:),23,[]);
    XT(:,:,i-Num_Graph_Learn)=[[a,p];ones(1,4)];
    AT=double(QM7_DB.Edges(:,:,i));
    AT(end+1,:)=1; % Bias
    AT(:,end+1)=1; % Bias
    AhT(:,:,i-Num_Graph_Learn)=A2Ah(AT);
  end
  ET=QM7_DB.Energy(Num_Graph_Learn+1:end); % Energy for regression purposes
  ET=double(ET');
  num_features=size(XT,2);
  Num_Graph=size(XT,3);
  %Num_Graph=100
% Detecting Saliency Maps
for test=1:Num_Graph
    X_Saliency = Saliency_Maps_Regression(XT,AhT,test,alpha);
    feature(test,:)=mean(X_Saliency,1);
    node(test,:)=(mean(X_Saliency,2))';
    Num_Graph-test
end
node_saliency=mean(node,1);
%node_saliency=node_saliency/sum(node_saliency);

feature_saliency=mean(feature,1);
%feature_saliency=feature_saliency/sum(feature_saliency);

figure
bar(extractdata(node_saliency));
title('Mean Node Saliency')

figure
bar(extractdata(feature_saliency));
title('Mean Feature Saliency')


%% functions Regression
function X_Saliency = Saliency_Maps_Regression(XT,AhT,test,alpha)
%Eq:2020_Saliency_Maps
global Ah1;
X1=XT(:,:,test);
Ah1=AhT(:,:,test);
Xp=dlarray(ones(size(XT,1),size(XT,2))/2);
gradX_acumulate=dlarray(zeros(size(XT,1),size(XT,2)));
for a=0:alpha:1
     XX=Xp+a*(X1-Xp);
     gradX=dlfeval(@Gradient_Compute_Energy_Regression,XX);
     gradX_acumulate=gradX_acumulate+gradX;
end
X_Saliency=abs((X1-Xp).*gradX_acumulate);
end

function gradX = Gradient_Compute_Energy_Regression(X)
 global W01;
 global Ah1;
 global num_features;
 global Regress_W;
 Ep=Compute_Energy_Regression(Ah1,X,W01,Regress_W,num_features);
 gradX = dlgradient(Ep,X);
end

function Ep=Compute_Energy_Regression(Ah,X,W01,Regress_W,num_features)
    Z=GCN(Ah,X,W01,num_features);
    Z_linear=[reshape(Z,1,[]),1];
    Ep=Z_linear*Regress_W;  
end


%% functions NN
function X_Saliency = Saliency_Maps_NN(XT,AhT,test,alpha)
%Eq:2020_Saliency_Maps
global Ah1;
X1=XT(:,:,test);
Ah1=AhT(:,:,test);
Xp=dlarray(ones(size(XT,1),size(XT,2))/2);
gradX_acumulate=dlarray(zeros(size(XT,1),size(XT,2)));
for a=0:alpha:1
     XX=Xp+a*(X1-Xp);
     gradX=dlfeval(@Gradient_Compute_Energy_NN,XX);
     gradX_acumulate=gradX_acumulate+gradX;
end
X_Saliency=abs((X1-Xp).*gradX_acumulate);
end

function gradX = Gradient_Compute_Energy_NN(X)
 global W01;
 global Ah1;
 global num_features;
 Ep=Compute_Energy_NN(Ah1,X,W01,num_features);
 gradX = dlgradient(Ep,X);
end

function Ep=Compute_Energy_NN(Ah,X,W01,num_features)
    Z=GCN(Ah,X,W01,num_features);
    Z_linear=[reshape(Z,1,[]),1];
    Ep=myNeuralNetworkFunction(extractdata(Z_linear)');
end

