function r=Z_Compress(Zstr,Znode,n)
%Z=sum([Zstr,Znode])./n; if Znode represents semantic features why is it
%not used, even when it is used, it's summed, not concatenated
rstr=sum(Zstr)./n;
r=[rstr, Znode];
%r=rstr;
%r= Znode;
end