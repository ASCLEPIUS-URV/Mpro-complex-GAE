% 2016 Kipf
% http://quantum-machine.org/datasets/

%% Graph Autoencoder
function [W01,l,sumabsgrad]=Step1_Learning_GAE(Dhid,Dout,numEpochs,learnRate)
 global X;
 global A;
 global nn; % number of real nodes before enlargement
 global Wpos;
 global Wneg;

%% Initilizing random weights
 num_features=size(X,2);
 W0=dlarray(rand(num_features,Dhid)-0.5);
 W1=dlarray(rand(Dhid,Dout)-0.5)';
 W01=[W0 ; W1];

%% Learning GAE
trailingAvg = [];
trailingAvgSq = [];
l=zeros(numEpochs,1);
sumabsgrad=zeros(numEpochs,1);

% learning the weights
for g=1:size(X,3)
     n=1:nn(g);
     N2=nn(g)*nn(g);
     Npos=sum(sum(A(n,n,g)));
     Nneg=N2-Npos;
     Wpos(g)=N2/(2*Npos);
     Wneg(g)=N2/(2*Nneg);
%      Wneg(g)=Npos/N2;
%      Wpos(g)=1-Wneg(g);
end

tic
for epoch=1:numEpochs
     [l(epoch),grad]=dlfeval(@objectiveAndGradient,W01);     
     [W01,trailingAvg,trailingAvgSq] = adamupdate(W01,grad,trailingAvg,trailingAvgSq,epoch,learnRate);
     sumabsgrad(epoch)=sum(sum(abs(grad)));
     t=toc*(numEpochs-epoch)/epoch;
     disp(ceil(t/60))
end
end
%% End main function


%% Functions
function [l,grad01] = objectiveAndGradient(W01)
 global Ah;
 global A;
 global X;
 global Wpos;
 global Wneg;
 global nn; % number of real nodes before enlargement
 l=0;
 for kkk=1:size(Ah,3)
   n=1:nn(kkk);
   l=l+loss_GAE(Ah(n,n,kkk),A(n,n,kkk),X(n,:,kkk),Wpos(kkk),Wneg(kkk),W01);
   grad01 = dlgradient(l,W01);
 end
 l=l/size(Ah,3);
end
 

function l=loss_GAE(Ah,A,X,Wpos,Wneg,W01)
        Z=GCN(Ah,X,W01);
        Ap=Decoder(Z);
        l=loss(A,Ap,Wpos,Wneg,Z);
end


