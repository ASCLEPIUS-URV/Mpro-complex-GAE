function [Regress_W,ET,ETp,E,ELp]=Learn_Regression(DataLearn,ActivityLearn,DataTest,ActivityTest,Learn,Test,W01)
[Ah,A,X,nn,E]=Step0_Read_Mpro(DataLearn,ActivityLearn);
[AhT,ATT,XT,nnT,ET]=Step0_Read_Mpro(DataTest,ActivityTest);
[Ah,A,X,E,nn]=Data_Selection(Ah,A,X,E,nn,Learn);
[AhT,ATT,XT,ET,nnT]=Data_Selection(AhT,ATT,XT,ET,nnT,Test);
[X,XT]=Step0_Data_Normalisation(X,XT);

Regress_W=Step3_Learning_Energy_Regression(Ah,X,E,W01,nn);
ETp = Step5_Compute_Regression(AhT,XT,W01,Regress_W,nnT);
ELp = Step5_Compute_Regression(Ah,X,W01,Regress_W,nn);
end

