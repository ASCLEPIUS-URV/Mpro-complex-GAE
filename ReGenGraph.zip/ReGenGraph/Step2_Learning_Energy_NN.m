%% Graph Autoencoder
clc; clear all; close all;
tic
%%Parameters
Num_perceptrons_hidden_layer=35;

%% Reading data
load('W01_QM7');
 Read_Data

%% Learning NN
for i=1:size(XL,3)
    Z=GCN(AhL(:,:,i),XL(:,:,i),W01,num_features);
    ZFinal(i,:)=reshape(Z,1,[]);
end
ZFinal=extractdata(ZFinal);
ZFinal(:,end+1)=ones(size(ZFinal,1),1);

net = feedforwardnet(Num_perceptrons_hidden_layer);
ZFinal=ZFinal';
EL=EL';
net = train(net,ZFinal,EL);
save('net','net');
toc/60

%EL_predicted = net(ZFinal);
% predicting the quality of the net
%perf = perform(net,EL,EL_predicted);
%Computing the derivatives
%dwb = defaultderiv('dperf_dwb',net,ZFinal,EL)

