function Z=GCN(Ah,X,W012)
num_features=size(X,2);
W0=W012(1:num_features,:);
W1=W012(num_features+1:end,:)';
L_h=GCN_h(Ah,X,W0);
Z=GCN_o(Ah,L_h,W1);
end

function A_h=GCN_h(A,X,W)
 A_h=relu(A*X*W);
 
end

function Aout=GCN_o(A,X,W)
 Aout=A*X*W;
end

