function Ap=Decoder(Z)
%         for i=1:size(Z,1)
%             Z(i,:)=Z(i,:)/norm(extractdata(Z(i,:)));
%         end
  Ap=sigmoid(Z*Z');
end

