
function [AhL,ALL,XL,nn,EL]=Step0_Read_Mpro(Ligand,Activity)
load(Ligand)
load(Activity)
v=1:size(Activity,1);
nn=Ligand.numnodes;
for i=1:length(v)
   XL(:,:,i)=Ligand.Nodes(:,:,v(i));
   %XL(:,:,i)=[Ligand.Nodes(:,:,v(i)),ones(size(Ligand.Nodes,1),1)];
   A=Ligand.Edges(:,:,v(i));
   for a=1:size(A,1)
   for b=1:size(A,2)
       if(A(a,b)>0) 
           A(a,b)=1;
       end
   end
   A(a,a)=1;
   end
   ALL(:,:,i)=A;
   AhL(:,:,i)=A2Ah(ALL(:,:,i));
end
Act=Activity(:,2);
for i=1:length(v)
    EL(i)=Act{v(i)};
end
EL=EL';
end

