function Ep = Step5_Compute_Regression(AhT,XT,W01,Regress_W,n)
Ep=dlarray(zeros(size(XT,3),1));
for i=1:size(XT,3)
    Zstr=GCN(AhT(:,:,i),XT(:,1:3,i),W01); %Why do learn the GCN again? because we don't save Z per node the first time.
    [Znode,~] = myNeuralNetworkFunction(XT(:,4,i));  %[Znode,~] = myNeuralNetworkFunction(XT(:,:,i)) Q:Should ZNode represent semantic features
    Znode=dlarray(Znode);
    Z=Z_Compress(Zstr,Znode',n(i));
    Z_linear=[Z,1];
    %Epn(i)=Z_linear*Regress_W; commented 23_2 %Ep(i)=Z_linear*Regress_W; What is Energy predicted per node and where do we use it?
    Ep(i)=Z_linear*Regress_W; %Added line
    %Ep(i)= myNNFunction_QM7(extractdata(Z_linear)); %added 
    %Ep(i)= myNeuralNetworkFunction(extractdata(Z_linear')); %replacing above line - Why do we call the NN twice?
end
Ep = extractdata(Ep);
end
