function [XL,XT]=Step0_Data_Normalisation(XL,XT)
for i=1:size(XL,2)
    S=std(reshape(XL(:,i,:),[],1));
    XL(:,i,:)=XL(:,i,:)/S;
    XT(:,i,:)=XT(:,i,:)/S;
end

% mmL=min(min(XL,[],3));
% MML=max(max(XL,[],3));
% mmT=min(min(XT,[],3));
% MMT=max(max(XT,[],3));
% 
% mm=min(mmL,mmT);
% MM=max(MML,MMT);
% MMmm=MM-mm;
% 
% for i=1:size(XL,3)
%     for j=1:size(XL,2)
%         XL(j,:,i)=((XL(j,:,i)-mm)./MMmm)-0.5;
%     end
% end
% for i=1:size(XT,3)
%     for j=1:size(XT,2)
%         XT(j,:,i)=((XT(j,:,i)-mm)./MMmm)-0.5;
%     end
% end

end