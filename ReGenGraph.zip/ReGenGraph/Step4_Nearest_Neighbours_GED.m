% 2016 Kipf

%% Graph Autoencoder
clc; clear all; close all;
% Parameters
  NodeInsDel=1;
  ArcInsDel=1;

%% Setting parameters

Read_Data

%% Testing the method
Ep = Compute_Energy_GED_All(extractdata(ALL),extractdata(XL),EL,ATT,XT,NodeInsDel,ArcInsDel);
save('Ep_1NN','Ep')
%% End of script

%% Functions
function Ep = Compute_Energy_GED_All(AL,XL,EL,AT,XT,NodeInsDel,ArcInsDel)
Num_Graph_Learn=size(XL,3);
Num_Graph_Test=size(XT,3);
Ep=zeros(Num_Graph_Test,1);
for i=1:Num_Graph_Test
    tic
    dmin=Inf;
    jj=0;
    XXi=XT(:,:,i);
    f=find(XXi(:,1)==0);
    if length(f)>0
        XXi=XXi(1:f(1)-1,:);
        AAi=AT(1:f(1)-1,1:f(1)-1,i);
    else
        AAi=AT(:,:,i);
    end
    for j=1:Num_Graph_Learn
        if i~=j
            XXj=XL(:,:,j);
            f=find(XXj(:,1)==0);
            if length(f)>0
                XXj=XXj(1:f(1)-1,:);
                AAj=AL(1:f(1)-1,1:f(1)-1,i);
            else
                AAj=AL(:,:,j);
            end
            d=(GED(XXi,XXj,AAi,AAj,NodeInsDel,ArcInsDel))/(size(XXi,1)+size(XXj,1));
            if d<dmin
                jj=j;
                dmin=d;
            end
        end
    end
    Ep(i)=EL(jj);
    Num_Graph_Test-i
    toc
end
end

