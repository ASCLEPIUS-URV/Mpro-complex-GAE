function d=dist_node(NA,NB)
if NA(1)==NB(1)
    d=norm(NA(2:4)-NB(2:4));
else
    d=10000;
end