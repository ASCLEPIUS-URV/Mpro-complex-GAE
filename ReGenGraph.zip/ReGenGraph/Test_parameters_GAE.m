clc, clear all, close all
% Dhid=20; % Dimension of the hiden layer
% Dout=20;  % Dimension of the latent domain
numEpochs = 300; % Epoch of the GAE
Learn=1:5;
Test=1:1;
DataLearn='Mpro_DB_Data.mat';
ActivityLearn='MPro_DB_Activity.mat';
DataTest='Mpro_DB_Data.mat';
ActivityTest='MPro_DB_Activity.mat';
% DataTest='NewMpro_DB_Data.mat';
% ActivityTest='NewMPro_DB_Activity.mat';

% DataLearn='New_Data_DB.mat';
% ActivityLearn='New_Data_DB_Activity.mat';

Results=[];
for Dhid=20:10:30
    for Dout=20:10:30
[e,DAp,DA,W01]=Learn_GAE(DataLearn,ActivityLearn,DataTest,ActivityTest,Learn,Test,Dhid,Dout,numEpochs);
    Results(end+1,:)=[e,DAp,DA,Dhid,Dout,numEpochs]
    end
end
save('Results','Results')


% figure
% histogram(error)
% title('Reconstruction error')
% figure
% histogram(Degre_Ap)
% title('Degree Ap')
% figure
% histogram(Degre_A)
% title('Degree A')

% ETp = Step5_Compute_Regression(AhT,XT,W01,Regress_W);
% Step6_Plot_Energy(ET,ETp,'New DB');

% e=find(abs(ETp-ET)<1);
% Step6_Plot_Energy(ET(e),ETp(e),'New DB');

% ELp = Step5_Compute_Regression(Ah,X,W01,Regress_W);
% Step6_Plot_Energy(E,ELp,'Learning DB');