function l=loss(A,Ap,Wpos,Wneg,Z)
n=size(A,1);

Wrong=Ap<=0;
Correct=Ap>0;
Ap=0.00001*Wrong+Ap.*Correct;
pos=Wpos*A.*log(Ap);

Wrong=Ap>=1;
Correct=Ap<1;
Ap=0.99999*Wrong+Ap.*Correct;
neg=Wneg*(1-A).*log(1-Ap);

% Zn=vecnorm(extractdata(Z),2,2);
% reg=((Zn-1)'*(Zn-1))/length(Zn);
% l=10*reg-(1/(n*n))*sum(sum(neg+pos));

l=-(1/(n*n))*sum(sum(neg+pos))
end
