clc, clear, close all
dd = uigetdir;
d=dir(strcat(dd,'/*.sdf'));
num=length(d);

Activity={};
j=1;
for i=1:length(d)
    filename=strcat(dd,"/",d(i).name);
    fileID=fopen(filename,'r');
    if fileID >= 0
        name=fscanf(fileID,'%s',1);
        nothingtodo=fscanf(fileID,'%s',1);
        while(nothingtodo~="<r_user_piC50>")
            nothingtodo=fscanf(fileID,'%s',1);
        end
        num=fscanf(fileID,'%f',1);
        Activity{j,1}=name;
        Activity{j,2}=num;
        j=j+1;
    end
    %display(floor(100*i/num));
end
save('MPro_DB_Activity','Activity');