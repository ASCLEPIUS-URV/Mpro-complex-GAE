%This script reads a matlab file which contains activities and it calcultates distance between ligands. 
clc;clear all;close all
%Reading
load("Activity.mat");
% Calculo de distancia entre actividades
num_nodos = size(Activity,1);
x=1;
for i=1:(num_nodos-1)
    for j=(i+1):num_nodos
        activities(x,1)=abs((Activity{i,2}-Activity{j,2}));
        x=x+1;
    end
end
% Calculo de distancia entre ligandos
d = uigetdir;
d=dir(strcat(d,'/*.mat'));
x=1;
for i=1:(length(d)-1)
    name=d(i).name;
    pathname=d(i).folder;
    file=strcat(pathname,'/',name);
    load(file);
    graph1=graph;
    for j=(i+1):(length(d))
        name=d(j).name;
        pathname=d(j).folder;
        file2=strcat(pathname,'/',name);
        load(file2);
        graph2=graph;
        activities(x,2)=GED(graph1.Nodes(:,1:3),graph2.Nodes(:,1:3),graph1.Edges,graph2.Edges,1,1);
        x=x+1;
    end
end
save('activities','activities')
% Representar graficamente (X -> distancia entre ligando ; Y -> distancia
% entre actividades)
plot(activities(:,2),activities(:,1),'*');