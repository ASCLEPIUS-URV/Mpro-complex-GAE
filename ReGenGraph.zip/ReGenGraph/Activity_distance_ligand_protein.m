%This script reads a matlab file which contains activities and it calcultates distance between ligands and proteins. 
clc;clear all;close all
%Reading
load("Activity.mat");
% Calculo de distancia entre actividades
num_nodos = size(Activity,1);
x=1;
for i=1:(num_nodos-1)
    for j=(i+1):num_nodos
        activities(x,1)=abs((Activity{i,2}-Activity{j,2}));
        x=x+1;
    end
end
% Calculo de distancia entre ligandos
d = uigetdir;
d = dir(strcat(d,'/*.mat'));
d2= uigetdir;
d2 = dir(strcat(d,'/*.mat'));
x=1;
for i=1:length(d)
    name=d(i).name;
    pathname=d(i).folder;
    file=strcat(pathname,'/',name);
    load(file);
    graph1=graph;
    for j=1:length(d2)
        name=d(j).name;
        pathname=d(j).folder;
        file2=strcat(pathname,'/',name);
        load(file2);
        graph2=graph;
        graph3 = Generate_Graph(graph1.Nodes(1:3),graph2.Nodes(1:3),graph1.Edges,graph2.edges,3,4);
        activities(x,2)=GED(graph1.Nodes(:,1:3),graph3.Nodes(:,1:3),graph1.Edges,graph3.Edges,1,1);
        x=x+1;
    end
end
% Representar graficamente (X -> distancia entre ligando ; Y -> distancia
% entre actividades)
plot(activities(:,2),activities(:,1));