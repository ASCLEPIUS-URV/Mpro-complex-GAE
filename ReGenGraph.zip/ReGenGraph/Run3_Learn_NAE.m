clc, clear all, close all
%

Configuration_MPro

%NN='myNeuralNetworkFunction'
[Xin,Xout,error,XXout]=Learn_NAE(DataLearn,ActivityLearn,DataTest,ActivityTest,Learn,Test,Dhiden_AE);
error
