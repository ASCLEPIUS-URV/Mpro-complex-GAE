clc, clear all, close all

Configuration_MPro

load W01
[Regress_W,ET,ETp,EL,ELp]=Learn_Regression(DataLearn,ActivityLearn,DataTest,ActivityTest,Learn,Test,W01);
%save('Regress_W','Regress_W')

EE=abs(ET-ETp);
%Step6_Plot_Energy(ET(EE<1),ETp(EE<1),'Test DB');
Step6_Plot_Energy(ET,ETp,'Test DB');
Step6_Plot_Energy(EL,ELp,'Learn DB');

% figure
% plot(nn_Test(Test),abs(ET-ETp),'*')

figure
histogram(extractdata(Regress_W))
title('Regression weights')
