clc;clear all;close all
nNodes=125; % initial value=87

NameDB='MPro_DB_Data'; % Max nodes 63 and 107 compounds
Data_DB_generation(NameDB,nNodes);

NameDB='New_Data_DB_Data'; % Max nodes 87 and 63 compounds
Data_DB_generation(NameDB,nNodes);
