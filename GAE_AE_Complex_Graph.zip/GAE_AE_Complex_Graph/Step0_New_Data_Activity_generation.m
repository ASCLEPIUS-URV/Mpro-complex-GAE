clc, clear, close all
[FILENAME, PATHNAME] = uigetfile('./*.xlsx');
[NUM,TXT,Activity]=xlsread(strcat(PATHNAME,FILENAME));
save('New_Data_DB_Activity','Activity');