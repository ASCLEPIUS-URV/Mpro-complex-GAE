clc, clear all, close all
%
% Z= [Nodes X Dout].

Configuration_MPro

[error,DAp,DA,W01,l,sumabsgrad,Z]=Learn_GAE(DataLearn,ActivityLearn,DataTest,ActivityTest,Learn,Test,Dhid,Dout,numEpochs);
save('W01','W01')
[error,DAp,DA]

plot(l)
title('loss')
figure
plot(sumabsgrad)
title('sumabsgrad')
