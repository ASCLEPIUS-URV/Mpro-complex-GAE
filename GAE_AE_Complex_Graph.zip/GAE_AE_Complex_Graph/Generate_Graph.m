
function [Nodesc,Edgesc]=Generate_Graph(Nodesl,Nodesp,Edgesl,Edgesp,thR,thC)
    Edgesc=Edgesl;
    [rowsEc,columnsEc]=size(Edgesc);
    Nodesc = Nodesl;
    CenterL = mean(Nodesl(:,1:3),1);
    rowsP = size(Nodesp,1);
    [rowsL,columnsL] = size(Nodesl);
    rowsC = size(Nodesc,1);
    j=1;
    % Generar nodos del nuevo grafo
    for i=1:rowsP
        distanceL = pdist2(Nodesp(i,1:3),CenterL);
        if(distanceL<thR)
            Nodesc(rowsC+j,:) = Nodesp(i,:);
            j=j+1;
        end
    end
    % Generar aristas entre ligando y proteina del nuevo grafo
    rowsC=size(Nodesc,1);
    for z=1:rowsL
        for x=(rowsL+1):rowsC
        distanceLP = pdist2(Nodesc(x,1:3),Nodesl(z,1:3));
                if(distanceLP < thC)
                    Edgesc(rowsEc+(x-rowsL),z) = 2;
                    Edgesc(z,columnsEc+(x-rowsL)) = 2;
                else
                    Edgesc(rowsEc+(x-rowsL),z) = 0;
                    Edgesc(z,columnsEc+(x-rowsL)) = 0;
                end
        end
    end
    % Generar aristas entre proteina y proteina del nuevo grafo
    [rowsEc,columnsEc]=size(Edgesc);
    for x=(rowsL+1):rowsEc
        for y=(columnsL+1):columnsEc
            if(Edgesp(x-rowsL,y-columnsL)==1)
                Edgesc(x,y)=1;
            end
        end
    end
end
