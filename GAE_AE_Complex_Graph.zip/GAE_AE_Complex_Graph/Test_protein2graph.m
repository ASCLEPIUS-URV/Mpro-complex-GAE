%This script generates a matlab file with a graph given a file with mol2 format. 

clc;clear all;close all
%% Test Protein
%Reading
d = uigetdir;
d=dir(strcat(d,'/*.mol2'));
for i=1:length(d)
    name=d(i).name;
    pathname=d(i).folder;
    file=strcat(pathname,'/',name);
    [error,graph]=protein2graph(file);
    if ~error
        graph_file=file(1:end-5);
        save(graph_file,'graph');
        disp('Reading Done')
    else
        disp('Reading Error')
    end
end 
