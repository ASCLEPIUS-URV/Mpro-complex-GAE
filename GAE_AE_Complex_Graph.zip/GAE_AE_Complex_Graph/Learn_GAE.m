function [error,DAp,DA,W01,l,sumabsgrad,Z]=Learn_GAE(DataLearn,ActivityLearn,DataTest,ActivityTest,Learn,Test,Dhid,Dout,numEpochs)
learnRate = 0.01; % 
 global Ah;
 global A;
 global X;
 global nn; % number of real nodes before enlargement

[Ah,A,XX,nn,E]=Step0_Read_Mpro(DataLearn,ActivityLearn);
[~,~,XT,~,~]=Step0_Read_Mpro(DataTest,ActivityTest);
[Ah,A,XX,~,nn]=Data_Selection(Ah,A,XX,E,nn,Learn);
[XX,~]=Step0_Data_Normalisation(XX,XT);
for i=1:size(XX,3)
    X(:,:,i)=XX(:,1:3,i); %% Only the 3D position
end

Ah=dlarray(Ah);
A=dlarray(A);
X=dlarray(X);
[W01,l,sumabsgrad]=Step1_Learning_GAE(Dhid,Dout,numEpochs,learnRate);
[error,Degre_Ap,Degre_A,Z]=Step1_Validating_Reconstruction_Edges(A,Ah,X,nn,W01);

DAp=sum(Degre_Ap)/length(error);
DA=sum(Degre_A)/length(error);
error=sum(error)/length(error);
end
