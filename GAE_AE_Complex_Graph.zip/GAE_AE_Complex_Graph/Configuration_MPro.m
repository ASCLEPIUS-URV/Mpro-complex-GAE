%Creating a dataset combining new and old data
old_x = load('Mpro_107_Data.mat');
old_y = load('MPro_107_Activity.mat');
new_x = load('Complex_53_Data.mat');
new_y= load('New_Data_53_Activity.mat');

nn = [new_x.Ligand.numnodes, old_x.Ligand.numnodes];
combined_nodes = zeros(146,4,size(nn,2));
combined_edges = zeros(146,146,size(nn,2));

combined_nodes(1:123,:,1:107) = old_x.Ligand.Nodes;
combined_nodes(:,:,108:160) = new_x.Ligand.Nodes;

combined_edges(1:123,1:123,1:107) = old_x.Ligand.Edges;
combined_edges(1:123,1:123,1:107) = old_x.Ligand.Edges;

% x_nodes = cat(3, old_x.Ligand.Nodes, new_x.Ligand.Nodes);
% x_edges = cat(3, old_x.Ligand.Edges, new_x.Ligand.Edges);

Ligand = struct;
Ligand.numnodes = nn;
Ligand.Nodes = combined_nodes;
Ligand.Edges = combined_edges;
% 
Activity = [new_y.Activity; old_y.Activity];
% 
% %Saving combined data
save('Ligand','Ligand');
save('Activity', 'Activity');

load('Ligand.mat')
nn = Ligand.numnodes;

%Loading saved data
DataLearn = 'Ligand.mat';
DataTest = 'Ligand.mat';
ActivityLearn='Activity.mat';
ActivityTest = 'Activity.mat';


%Filtering graphs by size 
Filter = find(nn>=0 & nn<=150);
% Learn = [Filter(1:47), Filter(57:107)];
% Test = Filter(48:56);

Learn = Filter(1:107);
Test = Learn;
nn_Learn=nn;
nn_Test=nn;
%Test=Learn;

%Autoencoder
Dhiden_AE=20;

%GAE
Dhid=100; % Dimension of the hiden layer. 
Dout=20;  % Dimension of the latent domain. 
numEpochs = 35; % Epoch of the GAE

