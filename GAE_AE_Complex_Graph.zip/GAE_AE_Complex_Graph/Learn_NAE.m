function [Xin,Xout,error,XXout]=Learn_NAE(DataLearn,ActivityLearn,DataTest,ActivityTest,Learn,Test,Dim)
% Dim: Dimensins of the latent space
[Ah,A,X,nn,E]=Step0_Read_Mpro(DataLearn,ActivityLearn);
[~,~,XT,~,~]=Step0_Read_Mpro(DataTest,ActivityTest);
[~,~,X,~,~]=Data_Selection(Ah,A,X,E,nn,Learn);
[X,~]=Step0_Data_Normalisation(X,XT);
for i=1:size(X,3) % Only the non coordinates.
    Xin(:,i)=X(:,4,i);
    Xout(:,i)=X(:,4,i);
end
net = feedforwardnet(Dim);
net = configure(net,Xin,Xout);
net.layers{1}.transferFcn = 'poslin';
net.layers{2}.transferFcn = 'purelin';
view(net)
net = train(net,Xin,Xout);
genFunction(net,'myNeuralNetworkFunction')
disp('Modify NN function [a1,Y]= ')
disp('Save')
disp('Press key')
open(strcat('myNeuralNetworkFunction','.m'));
pause
[error,XXout]=Step1_Validating_Reconstruction_Nodes(Xin);
end
