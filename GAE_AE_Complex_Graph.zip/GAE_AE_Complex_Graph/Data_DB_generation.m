function Data_DB_generation(NameDB,nNodes)
d = uigetdir;
dirData=dir(strcat(d,'/*.mol2'));
num=length(dirData);
XL=zeros(nNodes,4,1);  
AhL=zeros(nNodes,nNodes,1);  

target="ligand";
outputname=strcat(target,"_DB");
targetname=strcat(target,".mol2");
Graph_DB={};
i=1;
for k = 1 : num
    filename = dirData(k).name+"/"+targetname;
    graph_file=strcat(dirData(k).name, '_', target);
    if(dirData(k).name(1)~="." )
        disp(dirData(k).name)
        graphname=strcat(d,"/",dirData(k).name);
        [~,Graph_DB{i}]=ligand2graph(graphname);
        graph=Graph_DB{i};
        if size(graph.Nodes,1) > nNodes % graph reduction
           graph.Nodes=graph.Nodes(1:nNodes,:,:);
           graph.Edges=graph.Edges(1:nNodes,:,:);
           graph.Edges=graph.Edges(:,1:nNodes,:);
           graph.numnodes=nNodes;
        end

% Centering the compound 
        mmm=mean(graph.Nodes);
        graph.Nodes=graph.Nodes-mmm;
        numnodes(i)=graph.numnodes;
        XL(1:size(graph.Nodes,1),:,i)=graph.Nodes;
        AhL(1:size(graph.Nodes,1),1:size(graph.Nodes,1),i)=graph.Edges;
        i=i+1;
    end
end

Ligand.numnodes=numnodes;
Ligand.Nodes=XL;
Ligand.Edges=AhL;
save(NameDB,'Ligand');
disp("Done");
end

