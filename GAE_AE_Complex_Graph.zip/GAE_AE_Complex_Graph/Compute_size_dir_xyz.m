clc;clear all;close all
% Input a xyz (the whole component)
%% Parameters
MAXbonds=7; % max number of bonds per atom
Shell_radius=1000; % thickness of the shell in Amstrong
%% End Parameters
d = uigetdir;
disp(d(end-40:end))
d=dir(strcat(d,'/*.mol2'));
for i=1:length(d)
    name=d(i).name;
    pathname=d(i).folder;
    file=strcat(pathname,'/',name);
    [size_nm,error]=Compute_size_xyz(file);
    if ~error
        disp(strcat(name,'  Size (nm):',num2str(size_nm)))
    else
        disp(strcat(name,'  Reading Error'))
    end
end
disp('---Done---')

