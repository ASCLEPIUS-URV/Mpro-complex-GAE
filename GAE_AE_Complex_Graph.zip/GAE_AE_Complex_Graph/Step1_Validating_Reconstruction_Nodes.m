function [Reconstruction_error,XXout]=Step1_Validating_Reconstruction_Nodes(Xin)
[~,Xout] = myNeuralNetworkFunction(Xin);
XXout=reshape(Xout,1,[]);
XX=reshape(Xin,1,[]);
Reconstruction_error=norm(XX-XXout)/length(XX);
end