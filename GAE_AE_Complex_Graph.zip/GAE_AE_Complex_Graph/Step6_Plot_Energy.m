function Step6_Plot_Energy(ET,Ep,method)
%% Ploting final values
figure
plot(ET,Ep,'*')
%hold on
%plot([min(ET),max(ET)],[min(ET),max(ET)])
xlabel('pIC50');
ylabel('Predicted pIC50');
%legend('data','linear fit')
lsline
MSE=((ET-Ep)'*(ET-Ep))/length(ET);
t=strcat(method,': MSE=', num2str(MSE));
title(t)
figure
histogram(abs(ET-Ep))
t=strcat(method,': Error');
title(t)

%saveas(figure,strcat(method,'.png'))
end
