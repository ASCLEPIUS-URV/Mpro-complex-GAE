function Ah=A2Ah(A)
Degree=sum(A,2);
Dv=diag(1./sqrt(Degree));
Ah=Dv*A*Dv;
end
