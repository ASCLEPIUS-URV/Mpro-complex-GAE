% Detecting Saliency Maps
for test=1:Num_Graph
    X_Saliency = Saliency_Maps(test,alpha);
    feature(test,:)=mean(X_Saliency,1);
    node(test,:)=(mean(X_Saliency,2))';
    %Saliency_nodes(test)=
end
node_saliency=mean(node,1);
%node_saliency=node_saliency/sum(node_saliency);

feature_saliency=mean(feature,1);
%feature_saliency=feature_saliency/sum(feature_saliency);

figure
bar(extractdata(node_saliency));
title('Mean Node Saliency')

figure
bar(extractdata(feature_saliency));
title('Mean Feature Saliency')

function X_Saliency = Saliency_Maps(test,alpha)
%Eq:2020_Saliency_Maps
global X1;
global Ah1;
global X;
global Ah;
X1=X(:,:,test);
Ah1=Ah(:,:,test);

Xp=dlarray(ones(size(X,1),size(X,2))/2);
gradX_acumulate=dlarray(zeros(size(X,1),size(X,2)));
for a=0:alpha:1
     XX=Xp+a*(X1-Xp);
     gradX=dlfeval(@Gradient_Compute_Energy,XX);
     gradX_acumulate=gradX_acumulate+gradX;
end
X_Saliency=abs((X1-Xp).*gradX_acumulate);
end

function gradX = Gradient_Compute_Energy(X)
 global Ah1;
 global W01;
 global num_features;
 global Regress_W;
 Ep=Compute_Energy(Ah1,X,W01,num_features,Regress_W);
 gradX = dlgradient(Ep,X);
end

