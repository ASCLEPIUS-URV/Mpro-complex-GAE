function [Aho,Ao,Xo,Eo,nno]=Data_Selection(Ah,A,X,E,nn,v)
for i=1:length(v)
    Aho(:,:,i)=Ah(:,:,v(i));
    Ao(:,:,i)=A(:,:,v(i));
    Xo(:,:,i)=X(:,:,v(i));
    Eo(i,1)=E(v(i));
    nno(i)=nn(v(i));
end
end
